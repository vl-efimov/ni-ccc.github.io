from music_wave.cli import run

if __name__ == '__main__':
    # app = App()
    # app.run()
    run()
