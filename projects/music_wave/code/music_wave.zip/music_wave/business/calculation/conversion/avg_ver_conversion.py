import numpy as np

from music_wave.business.calculation.conversion.conversion import Conversion
from music_wave.business.calculation.conversion.similarities import Similarities


class AvgConversion(Conversion):
    TOLERANCE = 0.3

    def __init__(self, part):
        super().__init__(part)

    def convert(self):
        return int(np.average(self.part.image_raw_data[:, self.part.x], axis=0))

    def convert_in_percentage(self):
        value = self.convert()

        count = Similarities.count_similar_values(value, self.part.get_image_raw_data()[:, self.part.x], AvgConversion.TOLERANCE)
        percentage = count / self.part.get_image_raw_data()[:, self.part.x].shape[0]
        return percentage
