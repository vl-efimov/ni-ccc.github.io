import numpy as np

from music_wave.business.calculation.conversion.conversion import Conversion
from music_wave.business.calculation.conversion.similarities import Similarities


class AvgVertHorizConversion(Conversion):
    MARGIN = 30
    TOLERANCE = 0.3

    def __init__(self, part):
        super().__init__(part)
        self.surround_values = []

    def convert(self):
        self.surround_values = []
        for i in range(-1 * AvgVertHorizConversion.MARGIN, AvgVertHorizConversion.MARGIN + 1):
            index = max(0, min(self.part.x + i, self.part.image_raw_data.shape[1] - 1))
            self.surround_values.append(int(np.average(self.part.image_raw_data[:, index], axis=0)))

        margin = AvgVertHorizConversion.MARGIN
        step = 2.0 / AvgVertHorizConversion.MARGIN
        weights = [(-1 * (step * x) * (step * x) + 1)
                   for x in range(-1 * margin, margin + 1)]

        return int(np.average(self.surround_values, axis=0,  weights=weights))


    def convert_in_percentage(self):
        value = self.convert()

        count = Similarities.count_similar_values(value, self.part.image_raw_data[:, self.part.x],
                                                  AvgVertHorizConversion.TOLERANCE)
        percentage = count / len(self.part.image_raw_data[:, self.part.x])
        return percentage

