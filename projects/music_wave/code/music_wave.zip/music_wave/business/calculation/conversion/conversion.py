from abc import abstractmethod


class Conversion:

    def __init__(self, part):
        self.part = part

    @abstractmethod
    def convert(self):
        pass

    @abstractmethod
    def convert_in_percentage(self):
        pass
