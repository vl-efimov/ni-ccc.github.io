import numpy as np

from music_wave.business.calculation.conversion.conversion import Conversion
from music_wave.business.calculation.conversion.similarities import Similarities


class MaxVerticalConversion(Conversion):
    TOLERANCE = 0.3

    def __init__(self, part):
        super().__init__(part)

    def convert(self):
        data = self.part.get_image_raw_data()[:, self.part.x]
        return int(np.max(data, axis=0))

    def convert_in_percentage(self):
        value = self.convert()
        data = self.part.get_image_raw_data()[:, self.part.x]

        count = Similarities.count_similar_values(value, data, MaxVerticalConversion.TOLERANCE)
        percentage = count / data.shape[0]
        return percentage


