import random

from music_wave.business.calculation.conversion.conversion import Conversion


class RandomConversion(Conversion):

    def __init__(self, part):
        super().__init__(part)

    def convert(self):
        return random.randint(0, 255)

    def convert_in_percentage(self):
        return random.random()
