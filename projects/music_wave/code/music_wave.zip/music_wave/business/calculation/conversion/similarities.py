class Similarities:
    @staticmethod
    def is_similar(ref, value, tolerance):
        lower_bound = ref - tolerance * ref
        upper_bound = ref + tolerance * ref
        return (value >= lower_bound) and (value <= upper_bound)

    @staticmethod
    def count_similar_values(ref, data, tolerance):
        count = 0
        for value in data:
            if Similarities.is_similar(ref, value, tolerance):
                count += 1
        return count