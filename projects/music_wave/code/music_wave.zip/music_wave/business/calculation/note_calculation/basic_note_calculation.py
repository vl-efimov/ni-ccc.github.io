from music_wave.business.calculation.note_calculation.note_calculation import NoteCalculation


class BasicNoteCalculation(NoteCalculation):

    def __init__(self, image_reader):
        super().__init__(image_reader)

    def __next__(self):
        if self.finished:
            raise StopIteration

        # todo

    def __exit__(self):
        pass