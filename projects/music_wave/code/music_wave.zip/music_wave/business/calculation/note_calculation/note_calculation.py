from abc import abstractmethod

from music_wave.business.structs import Note


class NoteCalculation:

    def __init__(self, image_part):
        self.image_part = image_part

    def __iter__(self):
        self.notes_generated = 0
        self.finished = False
        return self

    @abstractmethod
    def __next__(self):
        if self.finished:
            raise StopIteration

        return Note()
        # todo

    @abstractmethod
    def __exit__(self):
        pass