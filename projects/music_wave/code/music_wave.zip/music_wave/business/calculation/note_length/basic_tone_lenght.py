import numpy as np

from music_wave.business.calculation.conversion.avg_ver_conversion import AvgConversion
from music_wave.business.calculation.note_length.tone_length_calc import ToneLengthCalc


class BasicLengthCalc(ToneLengthCalc):

    @staticmethod
    def calculate_length(part, conversion_method):
        conversion = conversion_method(part)
        percentage = conversion.convert_in_percentage()

        index = int(percentage * (len(ToneLengthCalc.TONE_LENGTH) - 1))

        # todo: inverted index
        # index = len(ToneLengthCalc.TONE_LENGTH) - 1 - index

        return ToneLengthCalc.TONE_LENGTH[index]
