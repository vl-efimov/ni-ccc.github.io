from abc import abstractmethod


class ToneLengthCalc:
    TONE_LENGTH = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
    TONE_LENGTH_REV = TONE_LENGTH[::-1]


    @staticmethod
    @abstractmethod
    def calculate_length(part, conversion_method):
        pass