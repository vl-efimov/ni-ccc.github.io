import numpy as np

from music_wave.business.calculation.conversion.avg_ver_conversion import AvgConversion
from music_wave.business.calculation.tone_height.tone_height_calc import ToneHeightCalc


class BasicToneHeightCalc(ToneHeightCalc):

    @staticmethod
    def calculate_height(part, conversion_method):
        conversion = conversion_method(part)
        conversion_value = conversion.convert()
        return int(conversion_value)
