from abc import abstractmethod


class ToneHeightCalc:
    def __init__(self, part):
        self.part = part

    @staticmethod
    @abstractmethod
    def calculate_height(part, conversion_method):
        pass
