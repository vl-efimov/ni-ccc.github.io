from collections import namedtuple


Note = namedtuple("Note", "height len")
GeneratedScore = namedtuple("GeneratedScore", "timbre notes")
InstrumentData = namedtuple("InstrumentData", "session notes")