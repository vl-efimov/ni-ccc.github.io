import random

from music_wave.business.calculation.note_length.basic_tone_lenght import BasicLengthCalc
from music_wave.business.calculation.tone_height.basic_tone_height_calc import BasicToneHeightCalc
from music_wave.business.structs import GeneratedScore, Note
from music_wave.business.transformation.basic_instrument import BasicInstrument
from music_wave.business.transformation.box_image_part import BoxImagePart
from music_wave.business.transformation.image_to_notes_tranformer import ImageToNotesTransformer
from music_wave.business.transformation.methods_names import calculation_methods


class BasicImageToNotesTransformer(ImageToNotesTransformer):
    def __init__(self, image_reader, instruments_count, method_height, method_len):
        super().__init__(image_reader, instruments_count, method_height, method_len)
        self.parts = []
        self.i = 0

    def transform(self):
        self.divide_into_parts()
        self.generate_notes()
        pass

    def get_score(self):
        return self.scores

    def generate_instrument(self, part):
        instrument = random.choice([
            # BasicInstrument("Steel Guitar", 40, 80),
            # BasicInstrument("Guitar Nylon X", 40, 80),
            # BasicInstrument("Violin", 40, 120),
            BasicInstrument("Acoustic Bass", 20, 70),
            # BasicInstrument("Bird", 40, 130),
            # BasicInstrument("Harp LP2", 40, 80),
            # BasicInstrument("Bright Piano", 30, 120),
            # BasicInstrument("Power", 30, 120),
            # BasicInstrument("Timpani Half", 30, 120),
            #
            # BasicInstrument("Power", 30, 120),
            # BasicInstrument("Timpani Half", 30, 120),
            # BasicInstrument("Power", 30, 120),
            # BasicInstrument("Timpani Half", 30, 120),
            # BasicInstrument("Power", 30, 120),
            # BasicInstrument("Timpani Half", 30, 120),
            # BasicInstrument("Power", 30, 120),
            # BasicInstrument("Timpani Half", 30, 120)
            ])
        #
        # array = [ BasicInstrument("Steel Guitar", 40, 100),
        #         BasicInstrument("Bright Piano", 30, 120),
        #         BasicInstrument("Bright Piano", 30, 120),
        #     BasicInstrument("Acoustic Bass", 20, 70)]
        #
        # instrument = array[self.i]
        # self.i += 1
        return instrument

    def generate_notes(self):
        print("height:", self.method_height,"\t", "len:", self.method_len)
        for part in self.parts:
            instrument = self.generate_instrument(part)
            notes = []
            for _ in part.__iter__():
                height = instrument.cut_to_range(
                    BasicToneHeightCalc.calculate_height(part, calculation_methods[self.method_height])
                )
                if height == instrument.range_min:
                    height = self.PAUSE_SIGNAL
                length = BasicLengthCalc.calculate_length(part, calculation_methods[self.method_len])
                notes += [Note(height, length)]
            self.scores += [GeneratedScore(instrument, notes)]
            # print("notes count =", len(notes))


    def divide_into_parts(self):
        start = 0
        count = int(self.image_reader.get_image_data().shape[0] / self.instruments_count)
        for i in range(self.instruments_count):
            self.parts += [BoxImagePart(self.image_reader.get_image_data()[start:(start + count), :])]
            start += count

