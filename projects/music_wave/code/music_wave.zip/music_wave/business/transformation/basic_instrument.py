from music_wave.business.transformation.instrument import Instrument


class BasicInstrument(Instrument):
    def __init__(self, name, range_min, range_max):
        super().__init__(name, range_min, range_max)


    def cut_to_range(self, value):
        if value > self.range_max:
            value = self.range_max
        elif value < self.range_min:
            value = self.range_min

        return value

    def get_name(self):
        return self.name

    # todo
    def map_to_range(self, value, old_range_min, old_range_max):
        pass