from music_wave.business.transformation.image_part import ImagePart


class BoxImagePart(ImagePart):
    def __init__(self, image_raw_data):
        super().__init__(image_raw_data)
        self.notes_generated = 0
        self.x = 0
        self.y = 0

    def __iter__(self):
        self.notes_generated = 0
        self.finished = False
        self.x = -1
        self.y = 0
        return self

    def __next__(self):
        # print(self.image_raw_data[self.x, self.y])
        self.x += 1
        # print("NEXT SHAPE", self.image_raw_data.shape)
        if self.x >= self.image_raw_data.shape[1]:
            raise StopIteration
        self.value = self.image_raw_data[self.y, self.x]
        return self


    def __exit__(self):
        pass

    def get_position_in_image(self):
        return self.x, self.y

    def get_image_raw_data(self):
        return self.image_raw_data
