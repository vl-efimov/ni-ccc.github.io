from abc import abstractmethod

import numpy as np


class ImagePart:
    def __init__(self,image_raw_data):
        self.image_raw_data = image_raw_data
        self.value = None
        self.finished = False

    @abstractmethod
    def __iter__(self):
        pass

    @abstractmethod
    def __next__(self):
        if self.finished:
            raise StopIteration

    @abstractmethod
    def __exit__(self):
        pass

    @abstractmethod
    def get_position_in_image(self):
        pass

    @abstractmethod
    def get_image_raw_data(self):
        pass
