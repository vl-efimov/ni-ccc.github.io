from abc import abstractmethod


class ImageToNotesTransformer:
    PAUSE_SIGNAL = -1

    @abstractmethod
    def __init__(self, image_reader, instruments_count, method_height, method_len):
        self.image_reader = image_reader
        self.instruments_count = instruments_count
        self.scores = []

        self.tone_height_calc = None
        self.tone_len_calc = None
        self.tone_color_calc = None
        self.pause_calc = None
        self.method_height = method_height
        self.method_len = method_len

    @abstractmethod
    def transform(self):
        pass

    @abstractmethod
    def get_score(self):
        pass







