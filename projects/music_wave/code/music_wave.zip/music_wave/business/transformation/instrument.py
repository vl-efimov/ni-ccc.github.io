from abc import abstractmethod


class Instrument:
    def __init__(self, name, range_min, range_max):
        self.name = name
        self.range_min = range_min
        self.range_max = range_max

    @abstractmethod
    def get_name(self):
        pass

    @abstractmethod
    def map_to_range(self, value, old_range_min, old_range_max):
        pass


    @abstractmethod
    def cut_to_range(self, value):
        pass