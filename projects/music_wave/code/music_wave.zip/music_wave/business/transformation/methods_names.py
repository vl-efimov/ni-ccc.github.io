from music_wave.business.calculation.conversion.avg_ver_horiz import AvgVertHorizConversion
from music_wave.business.calculation.conversion.avg_ver_conversion import AvgConversion
from music_wave.business.calculation.conversion.max_vertical import MaxVerticalConversion
from music_wave.business.calculation.conversion.random_conversion import RandomConversion

calculation_methods = {
    "Avg_ver": AvgConversion,
    "Max_ver" : MaxVerticalConversion,
    "Avg_ver_hor" : AvgVertHorizConversion,
    "Random" : RandomConversion,
}

calculation_method_height_default = "Avg_ver_hor"
calculation_method_len_default = "Avg_ver_hor"


