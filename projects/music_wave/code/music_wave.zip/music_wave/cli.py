import os

import click

from music_wave.business.transformation.methods_names import calculation_methods, calculation_method_height_default, \
    calculation_method_len_default
from music_wave.view.app import App


@click.command()
@click.option('--image_path', required=True, help='Path to source image')
@click.option('--title', required=False, default='', help='Title of created song (default is filename)', show_default=False)
@click.option('--composer', required=False, default='The image', help='Name of composer', show_default=True)
@click.option('--instruments_count', required=False, default=2, type=click.IntRange(1, 20, clamp=True), help='Count of instruments <1,20>', show_default=True)
@click.option('--tempo', required=False, default=120, type=click.IntRange(1, 300, clamp=True), help='Tempo <1,300>', show_default=True)
@click.option('--method_height', default=calculation_method_height_default, type=click.Choice(calculation_methods),
              help='Method for tone height calculation', show_default=True)
@click.option('--method_len', default=calculation_method_len_default, type=click.Choice(calculation_methods),
              help='Method for tone length calculation', show_default=True)
@click.option('--export_path', required=False, default="", help='Destination of the result (if empty same directory as the source image path is used)', show_default=False)
@click.option('--show', required=False, default=True, type=bool, help='Show generated music score file', show_default=True)
@click.option('--skip_playing', required=False, is_flag=True, default=False, type=bool, help='Only generate the score, don\'t play it', show_default=True)
def run(image_path, title, composer, instruments_count, tempo, method_height, method_len, export_path, show, skip_playing):
    if validate_input(image_path, title, composer, instruments_count, tempo, method_height, method_len, export_path, show, skip_playing):
        # composer = "tone height: {}, tone length: {}".format(method_height, method_len)
        app = App(image_path, title, composer, instruments_count, tempo, method_height, method_len, export_path, show, skip_playing)
        app.run()
    else:
        print("Invalid input.")


def validate_input(image_path, title, composer, instruments_count, tempo, method_height, method_len, export_path, show, skip_playing):
    if image_path == "":
        return False
    if not os.path.isfile(image_path):
        return False

    return True
