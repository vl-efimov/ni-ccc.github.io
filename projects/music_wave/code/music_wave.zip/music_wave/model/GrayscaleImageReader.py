from PIL import Image
from music_wave.model.image_reader import ImageReader
import numpy as np


class GrayscaleImageReader(ImageReader):
    def __init__(self):
        super().__init__()

    def load_image_data(self, path):
        with Image.open(path, mode="r") as img:
            self.image_data = np.asarray(img, dtype=np.uint8)

        weights = [0.299, 0.587, 0.114] if (self.image_data.shape[2] == 3) else [0.299, 0.587, 0.114, 1]
        self.image_data = np.asarray(np.average(self.image_data, weights=weights, axis=2), dtype=np.uint8)


    def get_pixel(self, x, y):
        return self.image_data[x, y]

    def get_image_data(self):
        return self.image_data
