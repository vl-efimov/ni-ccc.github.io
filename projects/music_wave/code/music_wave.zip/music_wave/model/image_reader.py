from abc import abstractmethod

class ImageReader:

    def __init__(self):
        self.image_data = None

    @abstractmethod
    def load_image_data(self, path):
        pass

    @abstractmethod
    def get_pixel(self, x, y):
        pass

    @abstractmethod
    def get_image_data(self):
        pass
