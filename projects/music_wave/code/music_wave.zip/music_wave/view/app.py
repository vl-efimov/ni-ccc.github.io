import os
import random
import time

from music_wave.business.transformation.basic_image_to_notes_transformer import BasicImageToNotesTransformer
from music_wave.model.GrayscaleImageReader import GrayscaleImageReader
from music_wave.view.sound_displayer import SoundDisplayer


class App:
    def __init__(self, image_path, title, composer, instruments_count, tempo, method_height, method_len, export_path, show, skip_playing):
        self.image_path = image_path
        self.title = title
        if self.title == "":
            _, self.title = os.path.split(self.image_path)
        self.composer = composer
        self.instruments_count = instruments_count
        self.tempo = tempo
        self.method_height = method_height
        self.method_len = method_len
        self.export_path = export_path
        self.show = show
        self.skip_playing = skip_playing

        self.image_reader = GrayscaleImageReader()
        self.image_to_notes_transformer \
            = BasicImageToNotesTransformer(self.image_reader, self.instruments_count, self.method_height, self.method_len)
        self.displayer = SoundDisplayer(self.image_reader, self.image_to_notes_transformer, self.title, self.composer,
                                        self.image_path, self.export_path, self.tempo, self.show, self.skip_playing)

        random.seed(time.time())

    def run(self):
        self.image_reader.load_image_data(self.image_path)
        self.image_to_notes_transformer.transform()
        self.displayer.display()





