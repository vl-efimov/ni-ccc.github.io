from abc import abstractmethod


class Displayer:

    def __init__(self, image_reader, image_to_note_transformer, title, composer, image_path,export_path, tempo, show, skip_playing):
        self.image_reader = image_reader
        self.image_to_note_transformer = image_to_note_transformer
        self.title = title
        self.composer = composer
        self.image_path = image_path
        self.tempo = tempo
        self.export_path = export_path
        self.show = show
        self.skip_playing = skip_playing
        self.scores = []

    @abstractmethod
    def display(self):
        pass
