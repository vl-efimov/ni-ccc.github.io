import os
import webbrowser

from clockblocks import current_clock

from music_wave.business.structs import InstrumentData
from music_wave.business.transformation.image_to_notes_tranformer import ImageToNotesTransformer
from music_wave.view.displayer import Displayer
import scamp as sc
from PIL import Image


class SoundDisplayer(Displayer):
    SEPARATOR = '#'
    DEF_SEPARATOR_LEN = 80

    def __init__(self, image_reader, image_to_note_transformer, title, composer, image_path, export_path, tempo, show, skip_playing):
        super().__init__(image_reader, image_to_note_transformer, title, composer, image_path, export_path, tempo, show, skip_playing)
        self.session = None
        self.instruments_data = None
        self.instrument_name = None

    def display(self):
        self.say_hello()
        self.display_image()
        self.add_instruments()
        self.create_export_settings()
        self.display_properties()
        self.start_music()
        self.say_bye()
        pass


    def display_image(self):
        print("Displaying '{}' ...".format(self.image_path))
        img = Image.open(self.image_path)
        img.show()
        img.close()

    def create_export_settings(self):
        if self.export_path == "":
            parent_path, file_base_name = os.path.split(self.image_path)
            self.export_path = parent_path + "/" + file_base_name + "_song" + ".pdf"


    @staticmethod
    def show_separator(line_len, message):
        if not message == "":
            message = " " + message + " "
        rest_line_len = line_len - len(message)
        first_part_count = int(rest_line_len / 2)
        second_part_count = rest_line_len - first_part_count
        print(SoundDisplayer.SEPARATOR * first_part_count, message, SoundDisplayer.SEPARATOR * second_part_count, sep="")

    def display_properties(self):
        SoundDisplayer.show_separator(SoundDisplayer.DEF_SEPARATOR_LEN, "Informations")
        print("Title:", self.title)
        print("Composer:", self.composer)
        print("Instruments:", ", ".join(self.instrument_name))
        print("Tempo:", self.tempo, "BPM")
        print("Source image:", self.image_path)
        print("Exported music score:", self.export_path)
        SoundDisplayer.show_separator(SoundDisplayer.DEF_SEPARATOR_LEN, "Progress")

    def say_bye(self):
        SoundDisplayer.show_separator(SoundDisplayer.DEF_SEPARATOR_LEN, "Bye :)")
        SoundDisplayer.show_separator(SoundDisplayer.DEF_SEPARATOR_LEN, "")

    def say_hello(self):
        SoundDisplayer.show_separator(SoundDisplayer.DEF_SEPARATOR_LEN, "")
        SoundDisplayer.show_separator(SoundDisplayer.DEF_SEPARATOR_LEN, "Music Wave")


    def add_instruments(self):
        self.session = sc.Session()
        self.scores = self.image_to_note_transformer.get_score()

        self.instruments_data = [InstrumentData(self.session.new_part(instrument.get_name()), notes)
                                 for instrument, notes in self.scores]
        self.instrument_name = [instrument.get_name() for instrument, _ in self.scores]

    def start_music(self):
        print("Transcribing has started...")

        # todo calculate the index of the last beat
        if self.skip_playing:
            self.session.fast_forward_to_beat(280000)
        else:
            print("Playing...")

        self.session.tempo = self.tempo
        self.session.start_transcribing(clock=current_clock())

        for instrument_data in self.instruments_data:
            self.session.fork(self.play_score, args=[instrument_data])

        self.session.wait_for_children_to_finish()
        performance = self.session.stop_transcribing()
        score_object = performance.to_score(title=self.title, composer=self.composer)
        score_object.export_pdf(self.export_path)

        print("\nTranscribing is done.")

        if self.show:
            print("Opening '{}' ...".format(self.export_path))
            webbrowser.open_new(self.export_path)


    def play_score(self, instrument_data):
        # print(instrument_data.notes)
        tmp_count = 0
        note_count = len(instrument_data.notes)

        for height, length in instrument_data.notes:
            # todo arrange threads
            tmp_count +=1
            print("\rnote: {}/{}".format(tmp_count, note_count), end="")
            if height != ImageToNotesTransformer.PAUSE_SIGNAL:
                instrument_data.session.play_note(height, 0.7, length)
            else:
                current_clock().wait(length)




